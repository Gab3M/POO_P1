﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NomeProprio
{
    internal class NomeProprio
    {
        //Atributos
        private string nome_completo;
        private string nome_paper;

        //Construtores
        public NomeProprio()
        {
            nome_completo = string.Empty;
            nome_paper = string.Empty;
        }

        public NomeProprio(string _nome_completo)
        {
            nome_completo = _nome_completo;
            string[] names = nome_completo.Split(' ');
            nome_paper = names[2] + ", " + names[0] + " " + names[1] + ".";
        }

        //Metodos
        public void ImprimeNomePaper()
        {
            Console.WriteLine(nome_paper);
        }
    }
}
