﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NomeProprio
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nome_temp = Console.ReadLine();
            NomeProprio nome = new NomeProprio(nome_temp);
            nome.ImprimeNomePaper();
        }
    }
}
