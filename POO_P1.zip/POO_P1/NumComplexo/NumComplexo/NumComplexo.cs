﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace NumComplexo
{
    internal class NumComplexo
    {
        //Atributos
        private double Re;
        private double Im;

        //Construtores
        public NumComplexo()
        {
            Re = 0;
            Im = 0;
        }

        public NumComplexo(double _re, double _im)
        {
            Re = _re;
            Im = _im;
        }

        //Getters & Setters
        public double getRe()
        {
            return Re;
        }
        public double getIm()
        {
            return Im;
        }
        public void setRe(double _re)
        {
            Re = _re;
        }
        public void setIm(double _im)
        {
            Re = _im;
        }

        //Metodos
        public NumComplexo soma(NumComplexo _num)
        {
            NumComplexo soma = new NumComplexo();
            soma.Re = this.Re + _num.Re;
            soma.Im = this.Im + _num.Im;
            return soma;
        }

        public NumComplexo vezes(NumComplexo _num)
        {
            NumComplexo vezes = new NumComplexo();
            vezes.Re = (this.Re * _num.Re) - (this.Im * _num.Im);
            vezes.Im = (this.Im * _num.Re) + (this.Re * _num.Im);
            return vezes;
        }

        public double Modulo()
        {
            double soma = Math.Pow(Re,2) + Math.Pow(Im,2);
            return Math.Sqrt(soma);
        }
        
        public double Argumento()
        {
            return Math.Atan(Im / Re);
        }

        public void ImprimePolar()
        {
            double modulo = Modulo();
            double argumento = Argumento();

            Console.WriteLine(modulo + "(cos" + argumento + " isen" + argumento + ")");
        }
    }
}
